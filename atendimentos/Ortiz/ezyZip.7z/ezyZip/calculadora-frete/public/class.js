
class EqEletronico {
    constructor(id, marca, nome, datadefabricacacao, cor, preco, produto, peso) {
        this.id = id;
        this.marca = marca;
        this.nome = nome;
        this.datadefabricacacao = datadefabricacacao;
        this.cor = cor;
        this.preco = preco;
        this.produto = produto;
        this.peso = peso;
    }
}
