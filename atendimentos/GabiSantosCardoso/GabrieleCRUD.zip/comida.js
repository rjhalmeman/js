class Comida{
    constructor(id,nome,dtfab,peso,dtval,tipo,posicaonalista){
        this.id=id;
        this.nome=nome;
        this.dtfab=dtfab;
        this.peso=peso;
        this.dtval=dtval;
        this.tipo=tipo

        this.posicaonalista=posicaonalista;
    }
}