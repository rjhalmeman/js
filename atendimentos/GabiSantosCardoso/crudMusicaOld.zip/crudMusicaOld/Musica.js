class Musica{
    constructor (id,nome,banda,album,lancamento,genero){
        this.id=id;
        this.nome=nome;
        this.banda=banda;
        this.album=album;
        this.lancamento=lancamento;
        this.genero=genero;
        this.posicaoNaLista = null;
    }
}