class Flor {
    constructor(id, nome, cien, cheiro, datap, quant) {
        this.id = id;
        this.nome = nome;
        this.cien = cien; 
        this.cheiro = cheiro; 
        this.datap = datap; 
        this.quant = quant; 

    }
}