class Pelucia{
    constructor (id,nome,formato,preco,lancamento,comprador){
        this.id=id;
        this.nome=nome;
        this.formato=formato;
        this.preco=preco;
        this.lancamento=lancamento;
        this.comprador=comprador;
        this.posicaoNaLista = null;
    }
}