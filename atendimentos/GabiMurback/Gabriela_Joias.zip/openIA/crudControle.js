class Joias {
    constructor(id, nome, metal, dataFabricacao, tipo, peso, posicaoNaLista) {
        this.id = id;
        this.nome = nome;
        this.metal = metal;
        this.dataFabricacao = dataFabricacao;
        this.tipo = tipo;
        this.peso = peso;
        this.posicaoNaLista=null;
    }
}